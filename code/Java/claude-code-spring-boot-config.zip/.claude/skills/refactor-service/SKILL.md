---
name: refactor-service
description: Use when refactoring service classes, improving code quality, or when user asks to refactor
argument-hint: [service-name]
allowed-tools: Read, Write, Edit, Grep
---

# Refactor Service

You will refactor the specified service following SOLID principles and clean code practices.

## Input
- Service name: $1

## Refactoring Process

### 1. Analyze Current Implementation

Read the service and identify:
- **Code smells**: Long methods, god class, feature envy, data clumps
- **SOLID violations**: Multiple responsibilities, tight coupling
- **Performance issues**: N+1 queries, missing caching
- **Testability issues**: Hard dependencies, static methods

### 2. Apply Refactoring Patterns

#### Extract Method
Break long methods into smaller, well-named private methods.
Each method should do one thing and do it well.

#### Extract Service (Single Responsibility)
If a service has multiple responsibilities, extract them into separate services.
Use dependency injection to wire them together.

#### Strategy Pattern (Replace Conditionals)
Replace complex if-else chains with strategy interfaces.
Each strategy handles one case and is independently testable.

### 3. Improve Testability

- Replace static method calls with injectable dependencies
- Use interfaces for external services
- Inject Clock instead of using LocalDateTime.now() directly
- Use factory methods for complex object creation

### 4. Optimize Performance

- Fix N+1 queries with JOIN FETCH or @EntityGraph
- Add @Cacheable for frequently accessed, rarely changed data
- Use pagination for large result sets
- Batch operations where possible

### 5. Add Caching

```java
@Cacheable(value = "products", key = "#id")
@Transactional(readOnly = true)
public ProductResponse getProduct(Long id) {
    return productRepository.findById(id)
        .map(ProductResponse::from)
        .orElseThrow(() -> new ProductNotFoundException(id));
}

@CacheEvict(value = "products", key = "#id")
public void updateProduct(Long id, UpdateProductRequest request) {
    // Update logic
}
```

## Refactoring Checklist

- [ ] Methods are < 20 lines
- [ ] Classes have single responsibility
- [ ] Dependencies are injected
- [ ] No code duplication
- [ ] Proper error handling
- [ ] Performance optimized
- [ ] Caching added where appropriate
- [ ] Tests still pass
- [ ] Code is more readable

## Output

1. Refactored service code
2. List of changes made
3. Explanation of each refactoring
4. Before/after metrics (lines of code, complexity)
5. Suggestions for further improvements
