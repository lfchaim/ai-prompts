---
name: create-endpoint
description: Use when creating new REST API endpoints, controllers, or when user asks to add a new API
argument-hint: [resource-name] [operation]
allowed-tools: Read, Write, Edit, Grep
---

# Create REST Endpoint

You will create a complete REST endpoint following Spring Boot best practices.

## Input
- Resource name: $1
- Operation: $2 (create, read, update, delete, list)

## Steps

### 1. Create Entity (if not exists)
```java
@Entity
@Table(name = "$1s")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class $1 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Add fields based on requirements

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
```

### 2. Create DTOs

**Request DTO:**
```java
public record Create$1Request(
    @NotBlank(message = "Name is required")
    @Size(max = 100)
    String name

    // Add other fields with validation
) {}
```

**Response DTO:**
```java
public record $1Response(
    Long id,
    String name,
    LocalDateTime createdAt
) {
    public static $1Response from($1 entity) {
        return new $1Response(
            entity.getId(),
            entity.getName(),
            entity.getCreatedAt()
        );
    }
}
```

### 3. Create Repository
```java
@Repository
public interface $1Repository extends JpaRepository<$1, Long> {
    // Add custom query methods if needed
}
```

### 4. Create Service Interface
```java
public interface $1Service {
    $1Response create(Create$1Request request);
    Optional<$1Response> findById(Long id);
    Page<$1Response> findAll(Pageable pageable);
    $1Response update(Long id, Update$1Request request);
    void delete(Long id);
}
```

### 5. Create Service Implementation
```java
@Service
@RequiredArgsConstructor
@Transactional
public class $1ServiceImpl implements $1Service {

    private final $1Repository repository;

    @Override
    public $1Response create(Create$1Request request) {
        var entity = new $1();
        // Map request to entity
        var saved = repository.save(entity);
        return $1Response.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<$1Response> findById(Long id) {
        return repository.findById(id)
            .map($1Response::from);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<$1Response> findAll(Pageable pageable) {
        return repository.findAll(pageable)
            .map($1Response::from);
    }

    @Override
    public $1Response update(Long id, Update$1Request request) {
        var entity = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("$1 not found: " + id));

        // Update entity fields

        var updated = repository.save(entity);
        return $1Response.from(updated);
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("$1 not found: " + id);
        }
        repository.deleteById(id);
    }
}
```

### 6. Create Controller
```java
@RestController
@RequestMapping("/api/v1/$1s")
@RequiredArgsConstructor
@Tag(name = "$1s", description = "$1 management APIs")
public class $1Controller {

    private final $1Service service;

    @PostMapping
    @Operation(summary = "Create new $1")
    public ResponseEntity<$1Response> create(
            @Valid @RequestBody Create$1Request request) {

        var created = service.create(request);
        var uri = ServletUriComponentsBuilder
            .fromCurrentRequest()
            .path("/{id}")
            .buildAndExpand(created.getId())
            .toUri();

        return ResponseEntity.created(uri).body(created);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get $1 by ID")
    public ResponseEntity<$1Response> getById(@PathVariable Long id) {
        return service.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    @Operation(summary = "List all $1s")
    public ResponseEntity<Page<$1Response>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "id") String sortBy) {

        var pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return ResponseEntity.ok(service.findAll(pageable));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update $1")
    public ResponseEntity<$1Response> update(
            @PathVariable Long id,
            @Valid @RequestBody Update$1Request request) {

        return ResponseEntity.ok(service.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete $1")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
```

### 7. Create Exception Handler (if not exists)
```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex) {
        var error = new ErrorResponse(
            LocalDateTime.now(),
            HttpStatus.NOT_FOUND.value(),
            "Not Found",
            ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        var errors = ex.getBindingResult()
            .getFieldErrors()
            .stream()
            .map(e -> new FieldError(e.getField(), e.getDefaultMessage()))
            .toList();

        var error = new ErrorResponse(
            LocalDateTime.now(),
            HttpStatus.BAD_REQUEST.value(),
            "Validation Failed",
            "One or more fields failed validation",
            errors
        );
        return ResponseEntity.badRequest().body(error);
    }
}
```

## Verification
After creating the endpoint:
1. Ensure all files compile without errors
2. Check that validation annotations are present
3. Verify proper HTTP status codes are returned
4. Confirm OpenAPI annotations are added
5. Suggest creating tests for the new endpoint
