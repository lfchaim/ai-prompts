---
name: api-documentation
description: Use when adding OpenAPI/Swagger documentation to controllers or when user asks for API docs
argument-hint: [controller-name]
allowed-tools: Read, Write, Edit, Grep
---

# Generate API Documentation

You will add comprehensive OpenAPI/Swagger documentation to the specified controller.

## Input
- Controller name: $1

## Documentation Strategy

### 1. Add Class-Level Annotations

```java
@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@Tag(
    name = "Users",
    description = "User management APIs. Provides CRUD operations and user search functionality."
)
@SecurityRequirement(name = "bearerAuth")
public class UserController {
    // ...
}
```

### 2. Document Each Endpoint

```java
@PostMapping
@Operation(
    summary = "Create new user",
    description = "Creates a new user account with the provided information.",
    responses = {
        @ApiResponse(
            responseCode = "201",
            description = "User created successfully",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = UserResponse.class)
            )
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Invalid input data",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = ErrorResponse.class)
            )
        ),
        @ApiResponse(
            responseCode = "409",
            description = "Email already exists",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = ErrorResponse.class)
            )
        )
    }
)
public ResponseEntity<UserResponse> createUser(
        @Valid @RequestBody CreateUserRequest request) {
    // Implementation
}
```

### 3. Document Path Variables and Parameters

```java
@GetMapping("/{id}")
@Operation(summary = "Get user by ID")
public ResponseEntity<UserResponse> getUser(
        @Parameter(description = "User ID", required = true, example = "123")
        @PathVariable Long id) {
    // Implementation
}

@GetMapping
@Operation(summary = "List all users")
public ResponseEntity<Page<UserResponse>> listUsers(
        @Parameter(description = "Page number (0-indexed)", example = "0")
        @RequestParam(defaultValue = "0") int page,

        @Parameter(description = "Page size", example = "20")
        @RequestParam(defaultValue = "20") int size,

        @Parameter(description = "Sort field", example = "name")
        @RequestParam(defaultValue = "id") String sortBy) {
    // Implementation
}
```

### 4. Document DTOs

```java
@Schema(description = "User creation request")
public record CreateUserRequest(
    @Schema(description = "User's full name", example = "John Doe", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "Name is required")
    @Size(max = 100)
    String name,

    @Schema(description = "User's email address", example = "john.doe@example.com", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank
    @Email(message = "Invalid email format")
    String email,

    @Schema(description = "User's password (min 8 characters)", example = "SecurePass123", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank
    @Size(min = 8, message = "Password must be at least 8 characters")
    String password
) {}
```

### 5. Configure OpenAPI in application.yml

```yaml
springdoc:
  api-docs:
    path: /api-docs
  swagger-ui:
    path: /swagger-ui.html
    operationsSorter: method
    tagsSorter: alpha
  default-produces-media-type: application/json
```

### 6. Add Security Scheme

```java
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("My API")
                .version("1.0.0")
                .description("API documentation"))
            .addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
            .components(new Components()
                .addSecuritySchemes("bearerAuth",
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")));
    }
}
```

## Documentation Checklist

- [ ] All endpoints documented with @Operation
- [ ] All parameters documented with @Parameter
- [ ] All responses documented with @ApiResponse
- [ ] Request/Response DTOs documented with @Schema
- [ ] Error responses documented
- [ ] Security requirements specified
- [ ] Examples provided for all fields
- [ ] Swagger UI accessible at /swagger-ui.html

## Output

1. Updated controller with OpenAPI annotations
2. Updated DTOs with @Schema annotations
3. OpenAPI configuration (if not exists)
4. Instructions to access Swagger UI
