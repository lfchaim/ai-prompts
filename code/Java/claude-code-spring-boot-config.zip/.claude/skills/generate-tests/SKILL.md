---
name: generate-tests
description: Use when creating unit tests, integration tests, or when user asks to generate tests for a service
argument-hint: [class-name]
allowed-tools: Read, Write, Edit, Grep
---

# Generate Test Suite

You will create a comprehensive test suite for the specified class.

## Input
- Class name: $1

## Test Generation Strategy

### 1. Analyze the Class
Read the source class and identify:
- Public methods to test
- Dependencies to mock
- Business rules to validate
- Edge cases to cover

### 2. Create Unit Test Class

```java
@ExtendWith(MockitoExtension.class)
class $1Test {

    // Mock dependencies
    @Mock
    private DependencyA dependencyA;

    @Mock
    private DependencyB dependencyB;

    @InjectMocks
    private $1 service;

    // Test data builders
    private TestDataBuilder builder;

    @BeforeEach
    void setUp() {
        builder = new TestDataBuilder();
    }

    // Generate tests for each public method
}
```

### 3. Test Categories

For each method, generate tests for:

**Happy Path:**
```java
@Test
void methodName_whenValidInput_thenReturnExpectedResult() {
    // Given
    var input = builder.validInput().build();
    when(dependency.method(any())).thenReturn(expectedValue);

    // When
    var result = service.methodName(input);

    // Then
    assertThat(result).isNotNull();
    assertThat(result.getField()).isEqualTo(expectedValue);
    verify(dependency).method(any());
}
```

**Edge Cases:**
```java
@Test
void methodName_whenNullInput_thenThrowException() {
    // Given
    InputType input = null;

    // When & Then
    assertThatThrownBy(() -> service.methodName(input))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("Input cannot be null");
}

@Test
void methodName_whenEmptyList_thenReturnEmptyResult() {
    // Given
    var input = Collections.emptyList();

    // When
    var result = service.methodName(input);

    // Then
    assertThat(result).isEmpty();
}
```

**Error Conditions:**
```java
@Test
void methodName_whenDependencyFails_thenPropagateException() {
    // Given
    var input = builder.validInput().build();
    when(dependency.method(any()))
        .thenThrow(new RuntimeException("Database error"));

    // When & Then
    assertThatThrownBy(() -> service.methodName(input))
        .isInstanceOf(RuntimeException.class)
        .hasMessageContaining("Database error");
}
```

**Business Rule Validation:**
```java
@Test
void methodName_whenBusinessRuleViolated_thenThrowBusinessException() {
    // Given
    var input = builder.invalidBusinessInput().build();

    // When & Then
    assertThatThrownBy(() -> service.methodName(input))
        .isInstanceOf(BusinessRuleException.class)
        .hasMessage("Business rule violated: [specific rule]");
}
```

### 4. Integration Test (if applicable)

```java
@SpringBootTest
@Testcontainers
class $1IntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private $1 service;

    @Autowired
    private Repository repository;

    @Test
    void methodName_whenRealDatabase_thenPersistCorrectly() {
        // Test with real database
    }
}
```

### 5. Test Data Builder

```java
public class TestDataBuilder {

    public InputBuilder validInput() {
        return new InputBuilder()
            .withField1("valid value")
            .withField2(100);
    }

    public InputBuilder invalidBusinessInput() {
        return new InputBuilder()
            .withField1("invalid value")
            .withField2(-1);
    }
}
```

## Coverage Targets

Generate tests to achieve:
- **Line coverage**: 90%+
- **Branch coverage**: 85%+
- **Method coverage**: 100%

## Test Naming Convention

Use format: `methodName_condition_expectedResult`

Examples:
- `createUser_whenValidRequest_thenReturnCreatedUser`
- `updateOrder_whenOrderNotExists_thenThrowNotFoundException`
- `calculateTotal_whenDiscountApplied_thenReturnDiscountedPrice`

## Output

1. Create unit test file at `src/test/java/.../$1Test.java`
2. Create integration test file at `src/test/java/.../$1IntegrationTest.java` (if applicable)
3. Create test data builder at `src/test/java/.../TestDataBuilder.java` (if needed)
4. Report expected coverage
5. Suggest additional edge cases to test
