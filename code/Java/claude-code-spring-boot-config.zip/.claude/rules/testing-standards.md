---
paths: ["**/src/test/**/*.java"]
---

## Testing Standards

### Unit Test Structure
```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void findById_whenUserExists_thenReturnUser() {
        // Given
        var user = new User(1L, "John");
        when(userRepository.findById(1L))
            .thenReturn(Optional.of(user));

        // When
        var result = userService.findById(1L);

        // Then
        assertThat(result).isPresent();
        assertThat(result.get().getName()).isEqualTo("John");
        verify(userRepository).findById(1L);
    }

    @Test
    void findById_whenUserNotExists_thenThrowException() {
        // Given
        when(userRepository.findById(1L))
            .thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> userService.findById(1L))
            .isInstanceOf(UserNotFoundException.class)
            .hasMessage("User not found: 1");
    }
}
```

### Integration Test with TestContainers
```java
@SpringBootTest
@Testcontainers
class UserRepositoryIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private UserRepository userRepository;

    @Test
    void save_whenValidUser_thenReturnSavedUser() {
        // Test implementation
    }
}
```

### Test Naming Convention
- Format: `methodName_condition_expectedResult`
- Examples:
  - `createOrder_whenValidRequest_thenReturnOrder`
  - `updateUser_whenUserNotExists_thenThrowNotFoundException`
  - `deleteOrder_whenOrderHasDependencies_thenThrowException`
