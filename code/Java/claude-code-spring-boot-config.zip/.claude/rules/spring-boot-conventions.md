---
paths: ["**/*.java", "**/*.kt"]
---

## Spring Boot Specific Conventions

### Dependency Injection
```java
// ✅ CORRECT: Constructor injection
@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final EmailService emailService;
}

// ❌ WRONG: Field injection
@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
}
```

### Configuration
```java
// Use @ConfigurationProperties for type-safe config
@ConfigurationProperties(prefix = "app.email")
public record EmailProperties(
    String host,
    int port,
    String username,
    String password
) {}
```

### Transaction Management
```java
// ✅ Apply @Transactional at service level
@Service
public class OrderService {

    @Transactional
    public Order createOrder(CreateOrderRequest request) {
        // Business logic
    }

    @Transactional(readOnly = true)
    public Order getOrder(Long id) {
        // Read-only operation
    }
}
```

### Validation
```java
// Use Bean Validation annotations
public record CreateUserRequest(
    @NotBlank(message = "Name is required")
    @Size(max = 100)
    String name,

    @NotBlank
    @Email(message = "Invalid email format")
    String email,

    @NotNull
    @Min(18)
    Integer age
) {}
```
