#!/bin/bash

# Pre-commit validation hook
# Validates Java code before saving

FILE_PATH="$1"

# Only validate Java files
if [[ "$FILE_PATH" == *.java ]]; then

    # Check for forbidden patterns
    if grep -q "@Autowired" "$FILE_PATH"; then
        echo "Warning: Field injection with @Autowired detected. Use constructor injection instead."
    fi

    if grep -q "System.out.println" "$FILE_PATH"; then
        echo "Error: System.out.println found. Use SLF4J logger instead."
        exit 1
    fi

    if grep -q "catch (Exception" "$FILE_PATH" && ! grep -q "throw" "$FILE_PATH"; then
        echo "Warning: Catching generic Exception without rethrowing. Consider specific exceptions."
    fi

    # Check for proper annotations
    if [[ "$FILE_PATH" == *Controller.java ]]; then
        if ! grep -q "@RestController\|@Controller" "$FILE_PATH"; then
            echo "Warning: Controller missing @RestController annotation."
        fi
    fi

    if [[ "$FILE_PATH" == *Service.java ]] || [[ "$FILE_PATH" == *ServiceImpl.java ]]; then
        if ! grep -q "@Service" "$FILE_PATH"; then
            echo "Warning: Service class missing @Service annotation."
        fi
    fi

    echo "Validation passed for $FILE_PATH"
fi

exit 0
