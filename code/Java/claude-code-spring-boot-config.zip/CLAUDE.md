# Spring Boot Project Configuration

## Project Overview
This is a Spring Boot application following industry best practices and clean architecture principles.

## Core Principles
- **Simplicity First**: Write minimal code that solves the problem. No over-engineering.
- **Surgical Changes**: Touch only what's necessary. Don't modify unrelated code.
- **Think Before Coding**: State assumptions explicitly before implementation.
- **Goal-Driven**: Define success criteria and verify implementation meets them.

## Technology Stack
- Java 21 (LTS)
- Spring Boot 3.3+
- Spring Data JPA with Hibernate
- Spring Security with OAuth2/JWT
- PostgreSQL/MySQL
- Maven/Gradle
- JUnit 5, Mockito, TestContainers

## Architecture Patterns

### Layered Architecture
```
Controller → Service → Repository → Entity
     ↓          ↓          ↓
   DTO      Domain      Database
```

### Package Structure
```
com.company.project/
├── config/          # Configuration classes
├── controller/      # REST controllers
├── service/         # Business logic
│   └── impl/        # Service implementations
├── repository/      # Data access layer
├── entity/          # JPA entities
├── dto/             # Data Transfer Objects
│   ├── request/     # Request DTOs
│   └── response/    # Response DTOs
├── mapper/          # MapStruct mappers
├── exception/       # Custom exceptions
├── security/        # Security configuration
└── util/            # Utility classes
```

## Code Conventions

### Naming Conventions
- **Classes**: PascalCase (UserService, OrderController)
- **Methods**: camelCase (findById, createOrder)
- **Constants**: UPPER_SNAKE_CASE (MAX_RETRY_ATTEMPTS)
- **Packages**: lowercase (com.company.project.service)
- **Database columns**: snake_case (created_at, user_id)

### Controllers
- Use `@RestController` for REST APIs
- Return `ResponseEntity<T>` for full HTTP control
- Use `@Valid` for request validation
- Prefix API endpoints with `/api/v1/`
- Use appropriate HTTP methods (GET, POST, PUT, DELETE, PATCH)

### Services
- Interface + Implementation pattern
- Use `@Service` annotation
- Inject dependencies via constructor (not `@Autowired` on fields)
- Keep business logic in services, not controllers
- Use `@Transactional` at service level

### Repositories
- Extend `JpaRepository<Entity, ID>`
- Use Spring Data query methods or `@Query` for complex queries
- Never expose entities directly to controllers (use DTOs)

### DTOs
- Use records for immutable DTOs (Java 16+)
- Separate Request and Response DTOs
- Use MapStruct for entity-DTO mapping
- Add validation annotations (@NotNull, @Size, @Email, etc.)

### Exception Handling
- Use `@ControllerAdvice` for global exception handling
- Create custom exceptions extending `RuntimeException`
- Return appropriate HTTP status codes
- Include error details in response body

## Testing Requirements
- Unit tests for services (JUnit 5 + Mockito)
- Integration tests for repositories (TestContainers)
- API tests for controllers (MockMvc)
- Minimum 80% code coverage
- Test naming: `methodName_condition_expectedResult`

## Security
- Never log sensitive data (passwords, tokens, PII)
- Use `@PreAuthorize` for method-level security
- Validate all inputs
- Use parameterized queries (prevent SQL injection)
- Implement CORS properly
- Use HTTPS in production

## Performance
- Use pagination for large result sets
- Implement caching with `@Cacheable` where appropriate
- Use `@EntityGraph` or `JOIN FETCH` to avoid N+1 queries
- Monitor with Spring Boot Actuator

## Documentation
- Document all public APIs with OpenAPI/Swagger annotations
- Use JavaDoc for complex business logic
- Keep README.md updated

## Git Conventions
- Commit messages: `type(scope): description`
- Types: feat, fix, refactor, test, docs, chore
- One commit per logical change
- Never commit secrets or .env files

## Forbidden Practices
- ❌ Field injection with `@Autowired`
- ❌ Returning entities from controllers
- ❌ Business logic in controllers
- ❌ Catching generic `Exception` without rethrowing
- ❌ Using `System.out.println` (use SLF4J logger)
- ❌ Hardcoding configuration values
- ❌ Modifying unrelated code during a task
